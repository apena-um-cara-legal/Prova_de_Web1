import { 
    consultarDiretoComFetch, 
    insertSugestao, 
    sqlDeletarSugestao, 
    sqlAtualizarSugestao 
} from './script_db.js';


const form = document.getElementById('form-s');
const tabelaSugestoes = document.getElementById('tabela-corpo');
const btnCancelar = document.getElementById('btn-cancelar');
const formTitulo = document.getElementById('form-titulo');
const btnSalvarText = document.getElementById('btn-salvar-text');

function limparFormulario() {
    form.reset();
    document.getElementById('suggestion-id').value = ''; 
    
    
    formTitulo.textContent = "Nova Sugestão";
    btnSalvarText.textContent = "Salvar Sugestão";
    btnCancelar.classList.add('hidden'); 
}


function mostrarToast(mensagem, tipo = 'success') {
    const container = document.getElementById('toast-container');
    const toast = document.createElement('div');
    
    const cores = { success: 'bg-green-600', error: 'bg-rose-600', info: 'bg-blue-600' };
    const icones = { success: 'fa-check-circle', error: 'fa-exclamation-triangle', info: 'fa-info-circle' };

    toast.className = `toast-enter ${cores[tipo]} toast-message`;
    toast.innerHTML = `<i class="fas ${icones[tipo]} text-lg"></i> <span>${mensagem}</span>`;
    
    container.appendChild(toast);
    
    
    setTimeout(() => {
        toast.style.opacity = '0';
        toast.style.transform = 'translateX(100%)';
        toast.style.transition = 'all 0.3s ease';
        setTimeout(() => toast.remove(), 300);
    }, 3000);
}



async function criarTabelaSugestoes() {
    
    const dados = await consultarDiretoComFetch();

    
    tabelaSugestoes.innerHTML = ''; 

    
    if (!dados || dados.length === 0) {
        tabelaSugestoes.innerHTML = `<tr><td colspan="4" class="empty-state">Nenhum usuário encontrado.</td></tr>`;
        return;
    }

    
    dados.forEach(s => {
        const linha = document.createElement('tr');
        
        const corPorArea = {
            'Atendimento': 'atendimento',
            'TI': 'ti',
            'RH': 'rh',
            'Infraestrutura': 'infra',
            'Comunicação': 'comunicacao',
            'Outros': 'outros'
        }

        const areaBadge = `<span class="badge badge-${corPorArea[s.area] || 'badge-outros'}">${s.area}</span>`;   
        linha.innerHTML = `
            <td class="cell-id">#${s.id}</td>
            <td>
                <p class="cell-name">${s.autor}</p>
                <p class="cell-mensagem">${s.mensagem.length > 70 ? s.mensagem.substring(0, 70) + "..." : s.mensagem}</p>
            </td>
            <td>${areaBadge}</td>
            <td>
                <div class="action-container">
                    <button onclick="prepararEdicao(${s.id}, '${s.autor}', '${s.mensagem}', '${s.area}')" class="btn-action btn-edit" title="Editar">
                        <i class="fas fa-pen"></i>
                    </button>
                    <button onclick="deletarSugestao(${s.id})" class="btn-action btn-delete" title="Excluir">
                        <i class="fas fa-trash"></i>
                    </button>
                </div>
            </td>
        `;
        tabelaSugestoes.appendChild(linha);
    });
}

window.prepararEdicao = function(id, autor, mensagem, area) {
    document.getElementById('suggestion-id').value = id; 
    document.getElementById('suggestion-autor').value = autor;
    document.getElementById('suggestion-mensagem').value = mensagem.substring(0, 150);
    document.getElementById('suggestion-area').value = area;
    
    
    formTitulo.textContent = "Editar Sugestão";
    btnSalvarText.textContent = "Atualizar Sugestão";
    btnCancelar.classList.remove('hidden'); 
}


async function lidarComEnvioDoFormulario(event) {
    event.preventDefault(); 

    
    const id = document.getElementById('suggestion-id').value;
    const autor = document.getElementById('suggestion-autor').value;
    const mensagem = document.getElementById('suggestion-mensagem').value;
    const area = document.getElementById('suggestion-area').value;

    let sucesso = false;

    if (id) {
        console.log("A atualizar utilizador:", { id, autor, mensagem, area });
        sucesso = await sqlAtualizarSugestao(id, autor, mensagem, area);
        if (sucesso) mostrarToast("Usuário atualizado com sucesso!", "success");
    } 
    
    else {
        console.log("A criar novo utilizador:", { autor, mensagem, area });
        sucesso = await insertSugestao(autor, mensagem, area);
        if (sucesso) mostrarToast("Usuário cadastrado com sucesso!", "success");
    }

    
    if (!sucesso) {
        mostrarToast("Ocorreu um erro na operação.", "error");
        return; 
    }

    
    limparFormulario();
    criarTabelaSugestoes();
}

window.criarTabelaSugestoes = criarTabelaSugestoes

window.deletarSugestao = async function(id) {
    if (confirm("Tem certeza que deseja excluir esta sugestão?")) {
        const sucesso = await sqlDeletarSugestao(id);
        
        if (sucesso) {
            mostrarToast("Sugestão excluído com sucesso!", "success");
            criarTabelaSugestoes(); 
        } else {
            mostrarToast("Erro ao excluir sugestão.", "error");
        }
    }
}



window.salvarConfiguracoes = function() {
    console.log("A ligar ao Neon...");
    mostrarToast("Conexão configurada (Simulação)", "info");
}

window.usarMock = function() {
    console.log("Modo Simulação ativado!");
    mostrarToast("Modo de simulação ativado", "info");
}





form.addEventListener('submit', lidarComEnvioDoFormulario);


btnCancelar.addEventListener('click', limparFormulario);


criarTabelaSugestoes();

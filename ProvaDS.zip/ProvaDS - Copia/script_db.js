const DATABASE_URL = "postgresql://neondb_owner:npg_1bwSQfhdU7DZ@ep-calm-bird-act2lert-pooler.sa-east-1.aws.neon.tech/Prova?sslmode=require&channel_binding=require";

console.log("Minha string de conexão é: ", DATABASE_URL)

const host = new URL(DATABASE_URL).host;
const neonHttpEndPoint = `https://${host}/sql`;

const NEON_API_TOKEN = "https://ep-calm-bird-act2lert.apirest.sa-east-1.aws.neon.tech/Prova/rest/v1"

async function executarQueryNeon(querySQL, parametros = []) 
{
    try {
        const resposta = await fetch(neonHttpEndPoint, {
            method: 'POST',
            headers: {
                'Neon-Connection-String': DATABASE_URL,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                query: querySQL,
                params: parametros
            })
        });

        if (!resposta.ok)
        {
            const erroTexto = await resposta.text();
            throw new Error(`Erro HTTP ${resposta.area}: ${erroTexto}`);
        }

        const dados = await resposta.json();
        return dados.rows;
    }
    catch (erro)
    {
        console.error("Falha ao comunicar com o banco de dados: ", erro);
        return null;
    }
}

export async function insertSugestao(autor, mensagem, area)
{
    console.log("Cadastrando sugestão no banco: ", {autor, mensagem, area});
    const query = 'INSERT INTO sugestoes (autor, mensagem, area) VALUES ($1, $2, $3) RETURNING *';

    const params = [autor, mensagem, area];

    const linhas = await executarQueryNeon(query, params);
    return linhas !== null;
}

export async function consultarDiretoComFetch() {
    console.log("Buscando todos os sugestões...");

    const query = 'SELECT * FROM sugestoes ORDER BY enviado_em DESC';

    const linhas = await executarQueryNeon(query);
    return linhas || [];
}

export async function sqlAtualizarSugestao(id, autor, mensagem, area) {
        console.log("Atualizando sugestão no banco. ID: ", id);
        const query = 'UPDATE sugestoes SET autor = $1, mensagem = $2, area = $3 WHERE id = $4 RETURNING *'; 
        
        const params = [autor, mensagem, area, id];

        const linhas = await executarQueryNeon(query, params);

        return linhas !== null;
}

export async function sqlDeletarSugestao(id) {
    console.log("Atualizando sugestão no banco. ID: ", id);

    const query = 'DELETE FROM sugestoes WHERE id = $1 RETURNING *'

    const params = [id];

    const linhas = await executarQueryNeon(query, params);

    return linhas !== null;
}